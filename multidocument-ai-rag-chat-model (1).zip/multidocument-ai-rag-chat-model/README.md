# Multi-Document AI RAG Chat Model

## Install
npm install

## Run
npm run dev