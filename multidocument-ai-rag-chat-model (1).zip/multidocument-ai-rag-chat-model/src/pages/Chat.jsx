import React, { useState } from "react";
import { Send, Upload } from "lucide-react";

export default function Chat() {
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState([]);

  const sendQuestion = async () => {
    if (!question) return;

    const userMsg = {
      role: "user",
      content: question,
    };

    setMessages((prev) => [...prev, userMsg]);

    const aiResponse = {
      role: "assistant",
      content:
        "This answer is generated using Multi-Document RAG model.",
    };

    setMessages((prev) => [...prev, aiResponse]);

    setQuestion("");
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-6">
        Multi Document AI RAG Chat
      </h1>

      <div className="bg-zinc-900 p-4 rounded-xl h-[500px] overflow-y-auto">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`mb-4 ${
              msg.role === "user"
                ? "text-right"
                : "text-left"
            }`}
          >
            <div className="inline-block bg-zinc-800 px-4 py-2 rounded-lg">
              {msg.content}
            </div>
          </div>
        ))}
      </div>

      <div className="flex gap-3 mt-4">
        <input
          type="text"
          placeholder="Ask question..."
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          className="flex-1 p-3 rounded-lg bg-zinc-800"
        />

        <button
          onClick={sendQuestion}
          className="bg-purple-600 px-5 rounded-lg"
        >
          <Send />
        </button>

        <button className="bg-blue-600 px-5 rounded-lg">
          <Upload />
        </button>
      </div>
    </div>
  );
}