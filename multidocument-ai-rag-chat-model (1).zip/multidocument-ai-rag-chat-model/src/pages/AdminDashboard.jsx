import React from "react";
import {
  Users,
  FileText,
  MessageSquare,
} from "lucide-react";

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-black text-white p-6">
      <h1 className="text-4xl font-bold mb-8">
        Admin Dashboard
      </h1>

      <div className="grid grid-cols-3 gap-6">
        <div className="bg-zinc-900 p-6 rounded-xl">
          <Users size={40} />
          <h2 className="text-2xl mt-4">120 Users</h2>
        </div>

        <div className="bg-zinc-900 p-6 rounded-xl">
          <FileText size={40} />
          <h2 className="text-2xl mt-4">
            560 Documents
          </h2>
        </div>

        <div className="bg-zinc-900 p-6 rounded-xl">
          <MessageSquare size={40} />
          <h2 className="text-2xl mt-4">
            3400 Chats
          </h2>
        </div>
      </div>
    </div>
  );
}