import React, { useState } from "react";

export default function Documents() {
  const [docs, setDocs] = useState([]);

  const uploadFile = (e) => {
    const file = e.target.files[0];

    if (file) {
      setDocs((prev) => [...prev, file.name]);
    }
  };

  return (
    <div className="p-6 text-white">
      <h2 className="text-2xl font-bold mb-4">
        Uploaded Documents
      </h2>

      <input type="file" onChange={uploadFile} />

      <div className="mt-4">
        {docs.map((doc, index) => (
          <div
            key={index}
            className="bg-zinc-800 p-3 rounded-lg mb-2"
          >
            {doc}
          </div>
        ))}
      </div>
    </div>
  );
}