import React from "react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center">
      <h1 className="text-5xl font-bold mb-6">
        NexusAI
      </h1>

      <p className="text-xl text-zinc-400 mb-8">
        Multi-Document AI RAG Chatbot
      </p>

      <button className="bg-purple-600 px-6 py-3 rounded-xl">
        Get Started
      </button>
    </div>
  );
}