import React from "react";
import Chat from "./Chat";
import Documents from "./Documents";

export default function Home() {
  return (
    <div className="grid grid-cols-3 min-h-screen bg-black">
      <div className="col-span-1 border-r border-zinc-800">
        <Documents />
      </div>

      <div className="col-span-2">
        <Chat />
      </div>
    </div>
  );
}